package view;

import javax.swing.JPanel;

public class Cabine extends JPanel {
	
}
