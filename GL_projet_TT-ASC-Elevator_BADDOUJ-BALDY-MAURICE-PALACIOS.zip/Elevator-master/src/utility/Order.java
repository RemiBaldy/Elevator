package utility;

public enum Order {
	MONTER,
	DESCENDRE,
	ARRET_PROCHAIN,
	ARRET_URGENT
}
