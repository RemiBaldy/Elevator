package utility;


public enum Sens {
	HAUT,
	BAS,
	ARRET,
}
